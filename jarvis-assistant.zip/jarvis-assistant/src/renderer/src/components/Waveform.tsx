import { useEffect, useRef } from 'react'

interface WaveformProps {
  frequencyData: Uint8Array | null
  active: boolean
  color?: string
}

export default function Waveform({
  frequencyData,
  active,
  color = '#00E1FE'
}: WaveformProps): JSX.Element {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    const draw = (): void => {
      const { width, height } = canvas
      ctx.clearRect(0, 0, width, height)

      const barCount = 40
      const gap = 3
      const barWidth = (width - gap * (barCount - 1)) / barCount

      for (let i = 0; i < barCount; i++) {
        let value = 0.06
        if (active && frequencyData && frequencyData.length > 0) {
          const idx = Math.floor((i / barCount) * frequencyData.length)
          value = Math.max(frequencyData[idx] / 255, 0.06)
        } else if (active) {
          value = 0.15 + Math.random() * 0.1
        }
        const barHeight = value * height
        const x = i * (barWidth + gap)
        const y = (height - barHeight) / 2

        ctx.fillStyle = color
        ctx.globalAlpha = active ? 0.9 : 0.25
        ctx.shadowColor = color
        ctx.shadowBlur = active ? 8 : 0
        ctx.fillRect(x, y, barWidth, barHeight)
      }

      rafRef.current = requestAnimationFrame(draw)
    }

    draw()
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
    }
  }, [active, frequencyData, color])

  return (
    <canvas
      ref={canvasRef}
      width={480}
      height={64}
      className="h-16 w-full max-w-md"
      aria-hidden="true"
    />
  )
}
