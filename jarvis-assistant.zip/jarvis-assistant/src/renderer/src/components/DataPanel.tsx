import { useMemo } from 'react'

interface DataPanelProps {
  title: string
  rows: { label: string; value: string }[]
  align?: 'left' | 'right'
}

export default function DataPanel({ title, rows, align = 'left' }: DataPanelProps): JSX.Element {
  const bars = useMemo(() => Array.from({ length: 14 }, () => 15 + Math.random() * 85), [])

  return (
    <div
      className={`w-56 rounded-sm border border-cyan-dim/40 bg-panel/60 px-3 py-2 backdrop-blur-sm ${
        align === 'right' ? 'text-right' : 'text-left'
      }`}
    >
      <div className="mb-1 flex items-center justify-between gap-2">
        <span className="font-display text-[10px] font-bold tracking-[0.2em] text-cyan-core/90">
          {title}
        </span>
        <span className="h-1.5 w-1.5 rounded-full bg-cyan-core shadow-[0_0_6px_#00E1FE] animate-pulse-glow" />
      </div>
      <div
        className={`mb-2 flex h-6 items-end gap-[2px] ${align === 'right' ? 'flex-row-reverse' : ''}`}
      >
        {bars.map((h, i) => (
          <div
            key={i}
            className="w-[3px] bg-cyan-core/70"
            style={{ height: `${h}%` }}
          />
        ))}
      </div>
      <dl className="space-y-0.5 font-mono text-[10px] text-cyan-core/70">
        {rows.map((row) => (
          <div key={row.label} className={`flex justify-between gap-3 ${align === 'right' ? 'flex-row-reverse' : ''}`}>
            <dt className="opacity-70">{row.label}</dt>
            <dd>{row.value}</dd>
          </div>
        ))}
      </dl>
    </div>
  )
}
