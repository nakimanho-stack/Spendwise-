import { useMemo } from 'react'
import type { EngineState } from '@renderer/types'

interface CoreVisualizerProps {
  state: EngineState
  level: number // 0..1 live amplitude driving the pulse
}

const STATE_LABEL: Record<EngineState, string> = {
  idle: 'STANDING BY',
  listening: 'LISTENING',
  thinking: 'PROCESSING',
  speaking: 'RESPONDING',
  error: 'SYSTEM FAULT'
}

const STATE_COLOR: Record<EngineState, string> = {
  idle: '#00E1FE',
  listening: '#19FFDB',
  thinking: '#7DF9FF',
  speaking: '#00E1FE',
  error: '#FF3B3B'
}

export default function CoreVisualizer({ state, level }: CoreVisualizerProps): JSX.Element {
  const color = STATE_COLOR[state]
  const scale = 1 + Math.min(level, 1) * 0.18
  const glowStrength = 8 + Math.min(level, 1) * 28

  // Ticks around the outer ring — purely decorative, static per mount.
  const ticks = useMemo(() => Array.from({ length: 48 }, (_, i) => i), [])

  return (
    <div className="relative flex h-[420px] w-[420px] items-center justify-center select-none">
      {/* Outer tick ring */}
      <svg
        viewBox="0 0 400 400"
        className="absolute inset-0 h-full w-full animate-spin-slow"
        style={{ opacity: 0.55 }}
      >
        {ticks.map((i) => {
          const angle = (i / ticks.length) * 360
          const isMajor = i % 4 === 0
          return (
            <line
              key={i}
              x1="200"
              y1={isMajor ? 14 : 20}
              x2="200"
              y2="28"
              stroke={color}
              strokeWidth={isMajor ? 2 : 1}
              transform={`rotate(${angle} 200 200)`}
            />
          )
        })}
      </svg>

      {/* Outer dashed ring */}
      <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full animate-spin-reverse-slow">
        <circle
          cx="200"
          cy="200"
          r="170"
          fill="none"
          stroke={color}
          strokeWidth="1.5"
          strokeDasharray="2 6"
          opacity={0.5}
        />
      </svg>

      {/* Segmented arc ring */}
      <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full animate-spin-slow">
        <circle
          cx="200"
          cy="200"
          r="145"
          fill="none"
          stroke={color}
          strokeWidth="3"
          strokeDasharray="18 14 4 14 60 14 4 14"
          opacity={0.7}
        />
      </svg>

      {/* Static fine ring */}
      <svg viewBox="0 0 400 400" className="absolute inset-0 h-full w-full">
        <circle cx="200" cy="200" r="120" fill="none" stroke={color} strokeWidth="1" opacity={0.35} />
      </svg>

      {/* Pulsing hexagon core */}
      <div
        className="absolute flex items-center justify-center transition-transform duration-150 ease-out"
        style={{ transform: `scale(${scale})` }}
      >
        <svg viewBox="0 0 200 200" className="h-[210px] w-[210px]">
          <polygon
            points="100,12 178,56 178,144 100,188 22,144 22,56"
            fill="rgba(0,225,254,0.05)"
            stroke={color}
            strokeWidth="2"
            style={{ filter: `drop-shadow(0 0 ${glowStrength}px ${color})` }}
          />
          <polygon
            points="100,38 156,70 156,130 100,162 44,130 44,70"
            fill="rgba(0,225,254,0.08)"
            stroke={color}
            strokeWidth="1.5"
            opacity={0.8}
          />
          <circle
            cx="100"
            cy="100"
            r={22 + Math.min(level, 1) * 10}
            fill={color}
            opacity={0.85}
            style={{ filter: `drop-shadow(0 0 ${glowStrength}px ${color})` }}
          />
        </svg>
      </div>

      {/* State label */}
      <div className="absolute -bottom-2 flex flex-col items-center gap-1">
        <span
          className="font-display text-[11px] font-bold tracking-[0.35em]"
          style={{ color, textShadow: `0 0 12px ${color}` }}
        >
          {STATE_LABEL[state]}
        </span>
      </div>
    </div>
  )
}
