import type { EngineState } from '@renderer/types'
import Waveform from './Waveform'

interface ControlBarProps {
  state: EngineState
  isListening: boolean
  muted: boolean
  isMicSupported: boolean
  frequencyData: Uint8Array | null
  onToggleListening: () => void
  onToggleMute: () => void
}

const MicIcon = ({ className }: { className?: string }): JSX.Element => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path
      d="M12 15a3 3 0 0 0 3-3V6a3 3 0 1 0-6 0v6a3 3 0 0 0 3 3Z"
      stroke="currentColor"
      strokeWidth="1.6"
    />
    <path d="M19 11a7 7 0 0 1-14 0M12 18v3" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </svg>
)

const SpeakerIcon = ({ className }: { className?: string }): JSX.Element => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path
      d="M4 9v6h4l5 4V5L8 9H4Z"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    <path d="M16.5 9a4.5 4.5 0 0 1 0 6" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </svg>
)

const SpeakerMuteIcon = ({ className }: { className?: string }): JSX.Element => (
  <svg viewBox="0 0 24 24" fill="none" className={className}>
    <path
      d="M4 9v6h4l5 4V5L8 9H4Z"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    <path d="M3 3l18 18" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
  </svg>
)

export default function ControlBar({
  state,
  isListening,
  muted,
  isMicSupported,
  frequencyData,
  onToggleListening,
  onToggleMute
}: ControlBarProps): JSX.Element {
  const busy = state === 'thinking' || state === 'speaking'

  return (
    <div className="flex w-full flex-col items-center gap-3 px-6 py-5">
      <Waveform frequencyData={frequencyData} active={isListening} />

      <div className="flex items-center gap-6">
        <button
          type="button"
          onClick={onToggleMute}
          title={muted ? 'Unmute JARVIS' : 'Mute JARVIS'}
          className={`flex h-11 w-11 items-center justify-center rounded-full border transition-colors ${
            muted
              ? 'border-red-400/60 text-red-400 shadow-[0_0_10px_rgba(255,59,59,0.4)]'
              : 'border-cyan-core/50 text-cyan-core/80 hover:border-cyan-core hover:text-cyan-core'
          }`}
        >
          {muted ? <SpeakerMuteIcon className="h-5 w-5" /> : <SpeakerIcon className="h-5 w-5" />}
        </button>

        <button
          type="button"
          onClick={onToggleListening}
          disabled={!isMicSupported || busy}
          title={isListening ? 'Stop listening' : 'Start listening'}
          className={`flex h-16 w-16 items-center justify-center rounded-full border-2 transition-all disabled:cursor-not-allowed disabled:opacity-40 ${
            isListening
              ? 'border-cyan-core bg-cyan-core/10 text-cyan-core shadow-[0_0_25px_rgba(0,225,254,0.6)] animate-pulse-glow'
              : 'border-cyan-core/50 text-cyan-core/80 hover:border-cyan-core hover:text-cyan-core'
          }`}
        >
          <MicIcon className="h-7 w-7" />
        </button>

        <div className="flex h-11 w-11 items-center justify-center">
          <span
            className={`h-2.5 w-2.5 rounded-full ${
              busy ? 'bg-yellow-300 shadow-[0_0_8px_#fde047] animate-pulse' : 'bg-cyan-core/30'
            }`}
          />
        </div>
      </div>

      {!isMicSupported && (
        <p className="font-mono text-[10px] text-red-400">
          Speech recognition is unavailable in this build environment, Sir.
        </p>
      )}
    </div>
  )
}
