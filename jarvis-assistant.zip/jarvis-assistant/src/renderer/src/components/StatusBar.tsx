import { useEffect, useState } from 'react'

export default function StatusBar(): JSX.Element {
  const [now, setNow] = useState(new Date())

  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000)
    return () => clearInterval(id)
  }, [])

  const time = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  const date = now.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })

  return (
    <div className="flex items-center justify-between px-6 py-4">
      <div className="flex items-center gap-3">
        <div className="flex h-9 w-9 items-center justify-center rounded-full border border-cyan-core/60">
          <div className="h-3 w-3 rounded-full bg-cyan-core shadow-[0_0_10px_#00E1FE] animate-pulse-glow" />
        </div>
        <div>
          <p className="font-display text-sm font-bold tracking-[0.3em] text-cyan-core">
            J.A.R.V.I.S.
          </p>
          <p className="font-mono text-[10px] tracking-widest text-cyan-core/50">
            VER 1.0 &middot; MHOS COMPATIBLE
          </p>
        </div>
      </div>

      <div className="text-right">
        <p className="font-mono text-xl tracking-[0.15em] text-cyan-core">{time}</p>
        <p className="font-mono text-[10px] tracking-widest text-cyan-core/50">{date}</p>
      </div>
    </div>
  )
}
