import { useEffect, useRef } from 'react'
import type { ChatEntry } from '@renderer/types'

interface TranscriptPanelProps {
  history: ChatEntry[]
  interimTranscript: string
}

export default function TranscriptPanel({
  history,
  interimTranscript
}: TranscriptPanelProps): JSX.Element {
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [history, interimTranscript])

  return (
    <div className="flex h-full w-full flex-col rounded-sm border border-cyan-dim/40 bg-panel/60 backdrop-blur-sm">
      <div className="border-b border-cyan-dim/30 px-4 py-2">
        <span className="font-display text-[10px] font-bold tracking-[0.25em] text-cyan-core/80">
          TRANSCRIPT LOG
        </span>
      </div>
      <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-3">
        {history.length === 0 && !interimTranscript && (
          <p className="font-mono text-xs text-cyan-core/40">
            Awaiting input, Sir. Tap the mic to begin.
          </p>
        )}
        {history.map((entry) => (
          <div key={entry.id} className="font-mono text-xs leading-relaxed">
            <span
              className={
                entry.role === 'user'
                  ? 'font-bold tracking-wide text-white/70'
                  : 'font-bold tracking-wide text-cyan-core'
              }
            >
              {entry.role === 'user' ? 'YOU' : 'JARVIS'}
            </span>
            <span className="text-cyan-core/40"> &raquo; </span>
            <span className={entry.role === 'user' ? 'text-white/60' : 'text-cyan-core/80'}>
              {entry.content}
            </span>
          </div>
        ))}
        {interimTranscript && (
          <div className="font-mono text-xs italic text-white/40">
            <span className="font-bold tracking-wide text-white/50">YOU</span>
            <span className="text-cyan-core/40"> &raquo; </span>
            {interimTranscript}
            <span className="animate-pulse">...</span>
          </div>
        )}
      </div>
    </div>
  )
}
