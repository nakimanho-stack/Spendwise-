import { useEffect, useState } from 'react'
import StatusBar from '@renderer/components/StatusBar'
import DataPanel from '@renderer/components/DataPanel'
import CoreVisualizer from '@renderer/components/CoreVisualizer'
import TranscriptPanel from '@renderer/components/TranscriptPanel'
import ControlBar from '@renderer/components/ControlBar'
import { useJarvisEngine } from '@renderer/hooks/useJarvisEngine'
import { useMicLevel } from '@renderer/hooks/useMicLevel'

export default function App(): JSX.Element {
  const {
    state,
    history,
    interimTranscript,
    isListening,
    speechLevel,
    muted,
    isMicSupported,
    toggleMute,
    toggleListening,
    errorMessage
  } = useJarvisEngine()

  const { level: micLevel, frequencyData } = useMicLevel(isListening)

  const [configWarning, setConfigWarning] = useState<string | null>(null)

  useEffect(() => {
    window.jarvis
      .configStatus()
      .then(({ hasAnthropicKey, hasElevenLabsKey }) => {
        if (!hasAnthropicKey || !hasElevenLabsKey) {
          const missing = [
            !hasAnthropicKey && 'ANTHROPIC_API_KEY',
            !hasElevenLabsKey && 'ELEVENLABS_API_KEY'
          ]
            .filter(Boolean)
            .join(' and ')
          setConfigWarning(`Missing ${missing} in .env — add your keys and restart JARVIS.`)
        }
      })
      .catch(() => setConfigWarning('Unable to verify API configuration.'))
  }, [])

  const coreLevel = isListening ? micLevel : state === 'speaking' ? speechLevel : 0.04

  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-void text-cyan-core">
      {/* Ambient background grid + scanline */}
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_center,rgba(0,90,110,0.18),transparent_65%)]" />
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.07]"
        style={{
          backgroundImage:
            'linear-gradient(#00E1FE 1px, transparent 1px), linear-gradient(90deg, #00E1FE 1px, transparent 1px)',
          backgroundSize: '42px 42px'
        }}
      />
      <div className="pointer-events-none absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-cyan-core/10 to-transparent animate-scanline" />

      <div className="relative z-10 flex h-full flex-col">
        <StatusBar />

        {configWarning && (
          <div className="mx-6 mb-2 rounded-sm border border-yellow-400/40 bg-yellow-400/5 px-3 py-1.5 font-mono text-[11px] text-yellow-300">
            {configWarning}
          </div>
        )}
        {errorMessage && (
          <div className="mx-6 mb-2 rounded-sm border border-red-400/40 bg-red-400/5 px-3 py-1.5 font-mono text-[11px] text-red-300">
            {errorMessage}
          </div>
        )}

        <div className="grid flex-1 grid-cols-[240px_1fr_240px] gap-4 overflow-hidden px-6 pb-2">
          {/* Left column */}
          <div className="flex flex-col items-start justify-center gap-4">
            <DataPanel
              title="AUDIO INPUT"
              rows={[
                { label: 'MODE', value: isListening ? 'LIVE' : 'IDLE' },
                { label: 'ENGINE', value: 'WEB-STT' },
                { label: 'GAIN', value: `${Math.round(micLevel * 100)}%` }
              ]}
            />
            <DataPanel
              title="LANGUAGE MODEL"
              rows={[
                { label: 'MODEL', value: 'CLAUDE' },
                { label: 'STATE', value: state.toUpperCase() },
                { label: 'MSGS', value: String(history.length) }
              ]}
            />
          </div>

          {/* Center column */}
          <div className="flex flex-col items-center justify-center gap-4">
            <CoreVisualizer state={state} level={coreLevel} />
          </div>

          {/* Right column */}
          <div className="flex flex-col items-end justify-center gap-4">
            <DataPanel
              align="right"
              title="VOICE SYNTH"
              rows={[
                { label: 'PROVIDER', value: 'ELEVENLABS' },
                { label: 'OUTPUT', value: muted ? 'MUTED' : 'ACTIVE' },
                { label: 'LEVEL', value: `${Math.round(speechLevel * 100)}%` }
              ]}
            />
            <DataPanel
              align="right"
              title="SYSTEM"
              rows={[
                { label: 'OS', value: 'MHOS' },
                { label: 'CORE', value: 'IRONIS' },
                { label: 'STATUS', value: 'NOMINAL' }
              ]}
            />
          </div>
        </div>

        <div className="px-6 pb-2">
          <div className="h-40">
            <TranscriptPanel history={history} interimTranscript={interimTranscript} />
          </div>
        </div>

        <ControlBar
          state={state}
          isListening={isListening}
          muted={muted}
          isMicSupported={isMicSupported}
          frequencyData={frequencyData}
          onToggleListening={toggleListening}
          onToggleMute={toggleMute}
        />

        <div className="pb-3 text-center">
          <span className="font-display text-[10px] font-bold tracking-[0.6em] text-cyan-core/40">
            STARK INDUSTRIES
          </span>
        </div>
      </div>
    </div>
  )
}
