import { useCallback, useEffect, useRef, useState } from 'react'
import type { ChatEntry, EngineState } from '@renderer/types'
import { useSpeechRecognition } from './useSpeechRecognition'
import { useVoicePlayback } from './useVoicePlayback'

function makeId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`
}

interface UseJarvisEngineReturn {
  state: EngineState
  history: ChatEntry[]
  interimTranscript: string
  isListening: boolean
  speechLevel: number
  muted: boolean
  isMicSupported: boolean
  toggleMute: () => void
  toggleListening: () => void
  errorMessage: string | null
}

export function useJarvisEngine(): UseJarvisEngineReturn {
  const [state, setState] = useState<EngineState>('idle')
  const [history, setHistory] = useState<ChatEntry[]>([])
  const [muted, setMuted] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const historyRef = useRef<ChatEntry[]>([])

  const { isSpeaking, level: speechLevel, speak, stop: stopSpeaking } = useVoicePlayback(muted)

  const handleFinalTranscript = useCallback(
    async (transcript: string) => {
      const userEntry: ChatEntry = {
        id: makeId(),
        role: 'user',
        content: transcript,
        timestamp: Date.now()
      }
      historyRef.current = [...historyRef.current, userEntry]
      setHistory(historyRef.current)
      setState('thinking')
      setErrorMessage(null)

      try {
        const reply = await window.jarvis.chat(
          historyRef.current.map(({ role, content }) => ({ role, content }))
        )

        const assistantEntry: ChatEntry = {
          id: makeId(),
          role: 'assistant',
          content: reply,
          timestamp: Date.now()
        }
        historyRef.current = [...historyRef.current, assistantEntry]
        setHistory(historyRef.current)

        setState('speaking')
        await speak(reply)
        setState('idle')
      } catch (err) {
        console.error('JARVIS engine error:', err)
        setErrorMessage(err instanceof Error ? err.message : 'Something went wrong, Sir.')
        setState('error')
      }
    },
    [speak]
  )

  const {
    isListening,
    interimTranscript,
    isSupported: isMicSupported,
    start: startListening,
    stop: stopListening
  } = useSpeechRecognition({
    onFinalResult: handleFinalTranscript,
    disabled: state === 'thinking' || state === 'speaking'
  })

  // Keep the high-level engine state in sync with the recognizer's own
  // lifecycle (it can end itself after silence, errors, etc).
  useEffect(() => {
    if (isListening) {
      setState('listening')
    } else {
      setState((prev) => (prev === 'listening' ? 'idle' : prev))
    }
  }, [isListening])

  const toggleListening = useCallback(() => {
    if (isSpeaking) stopSpeaking()
    if (isListening) {
      stopListening()
    } else {
      startListening()
    }
  }, [isListening, isSpeaking, startListening, stopListening, stopSpeaking])

  const toggleMute = useCallback(() => {
    setMuted((m) => {
      if (!m) stopSpeaking()
      return !m
    })
  }, [stopSpeaking])

  return {
    state,
    history,
    interimTranscript,
    isListening,
    speechLevel,
    muted,
    isMicSupported,
    toggleMute,
    toggleListening,
    errorMessage
  }
}
