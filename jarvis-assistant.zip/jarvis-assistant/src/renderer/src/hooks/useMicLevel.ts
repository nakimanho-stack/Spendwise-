import { useEffect, useRef, useState } from 'react'

/**
 * Opens the microphone while `active` is true and returns:
 *  - `level`: a smoothed 0..1 amplitude value, handy for simple pulsing UI
 *  - `frequencyData`: a live-updating byte array, handy for drawing a waveform/bars
 */
export function useMicLevel(active: boolean): {
  level: number
  frequencyData: Uint8Array | null
} {
  const [level, setLevel] = useState(0)
  const frequencyDataRef = useRef<Uint8Array | null>(null)
  const [, forceTick] = useState(0)

  const streamRef = useRef<MediaStream | null>(null)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const rafRef = useRef<number | null>(null)

  useEffect(() => {
    let cancelled = false

    async function setup(): Promise<void> {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop())
          return
        }
        streamRef.current = stream

        const audioCtx = new AudioContext()
        audioCtxRef.current = audioCtx
        const source = audioCtx.createMediaStreamSource(stream)
        const analyser = audioCtx.createAnalyser()
        analyser.fftSize = 256
        analyser.smoothingTimeConstant = 0.75
        source.connect(analyser)

        const data = new Uint8Array(analyser.frequencyBinCount)
        frequencyDataRef.current = data

        const tick = (): void => {
          analyser.getByteFrequencyData(data)
          const avg = data.reduce((sum, v) => sum + v, 0) / data.length
          setLevel(avg / 255)
          forceTick((n) => n + 1)
          rafRef.current = requestAnimationFrame(tick)
        }
        tick()
      } catch (err) {
        console.error('JARVIS: microphone access failed', err)
      }
    }

    if (active) {
      setup()
    }

    return () => {
      cancelled = true
      if (rafRef.current) cancelAnimationFrame(rafRef.current)
      streamRef.current?.getTracks().forEach((t) => t.stop())
      audioCtxRef.current?.close().catch(() => {})
      streamRef.current = null
      audioCtxRef.current = null
      frequencyDataRef.current = null
      setLevel(0)
    }
  }, [active])

  return { level, frequencyData: frequencyDataRef.current }
}
