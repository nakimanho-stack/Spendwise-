import { useCallback, useEffect, useRef, useState } from 'react'

interface UseSpeechRecognitionOptions {
  onFinalResult: (transcript: string) => void
  disabled?: boolean
}

interface UseSpeechRecognitionReturn {
  isListening: boolean
  interimTranscript: string
  isSupported: boolean
  start: () => void
  stop: () => void
}

/**
 * Continuous speech-to-text session. Chrome/Electron's SpeechRecognition
 * fires a `result` with `isFinal: true` once it detects a pause after speech,
 * which is what gives us automatic end-of-utterance detection for free —
 * no manual VAD or push-to-talk needed.
 */
export function useSpeechRecognition({
  onFinalResult,
  disabled = false
}: UseSpeechRecognitionOptions): UseSpeechRecognitionReturn {
  const [isListening, setIsListening] = useState(false)
  const [interimTranscript, setInterimTranscript] = useState('')
  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const onFinalResultRef = useRef(onFinalResult)
  onFinalResultRef.current = onFinalResult

  const SpeechRecognitionCtor =
    typeof window !== 'undefined'
      ? window.SpeechRecognition || window.webkitSpeechRecognition
      : undefined
  const isSupported = Boolean(SpeechRecognitionCtor)

  useEffect(() => {
    if (!SpeechRecognitionCtor) return

    const recognition = new SpeechRecognitionCtor()
    recognition.continuous = false
    recognition.interimResults = true
    recognition.lang = 'en-US'
    recognition.maxAlternatives = 1

    recognition.onstart = () => setIsListening(true)

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      let interim = ''
      let final = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const result = event.results[i]
        if (result.isFinal) {
          final += result[0].transcript
        } else {
          interim += result[0].transcript
        }
      }
      if (interim) setInterimTranscript(interim)
      if (final.trim()) {
        setInterimTranscript('')
        onFinalResultRef.current(final.trim())
      }
    }

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      if (event.error !== 'no-speech' && event.error !== 'aborted') {
        console.error('JARVIS: speech recognition error', event.error)
      }
    }

    recognition.onend = () => {
      setIsListening(false)
      setInterimTranscript('')
    }

    recognitionRef.current = recognition

    return () => {
      recognition.onresult = null
      recognition.onerror = null
      recognition.onend = null
      recognition.onstart = null
      recognition.abort()
      recognitionRef.current = null
    }
  }, [SpeechRecognitionCtor])

  const start = useCallback(() => {
    if (disabled || !recognitionRef.current || isListening) return
    try {
      recognitionRef.current.start()
    } catch {
      // start() throws if already started — safe to ignore
    }
  }, [disabled, isListening])

  const stop = useCallback(() => {
    recognitionRef.current?.stop()
  }, [])

  return { isListening, interimTranscript, isSupported, start, stop }
}
