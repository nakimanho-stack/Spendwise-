import { useCallback, useEffect, useRef, useState } from 'react'

interface UseVoicePlaybackReturn {
  isSpeaking: boolean
  level: number
  speak: (text: string) => Promise<void>
  stop: () => void
}

export function useVoicePlayback(muted: boolean): UseVoicePlaybackReturn {
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [level, setLevel] = useState(0)

  const audioRef = useRef<HTMLAudioElement | null>(null)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const rafRef = useRef<number | null>(null)
  const objectUrlRef = useRef<string | null>(null)

  const cleanupPlayback = useCallback(() => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    rafRef.current = null
    if (objectUrlRef.current) {
      URL.revokeObjectURL(objectUrlRef.current)
      objectUrlRef.current = null
    }
    setLevel(0)
    setIsSpeaking(false)
  }, [])

  const stop = useCallback(() => {
    audioRef.current?.pause()
    if (audioRef.current) audioRef.current.currentTime = 0
    cleanupPlayback()
  }, [cleanupPlayback])

  useEffect(() => {
    return () => {
      stop()
      audioCtxRef.current?.close().catch(() => {})
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const speak = useCallback(
    async (text: string) => {
      if (muted || !text.trim()) return

      const bytes = await window.jarvis.speak(text)
      const blob = new Blob([new Uint8Array(bytes)], { type: 'audio/mpeg' })
      const url = URL.createObjectURL(blob)
      objectUrlRef.current = url

      const audio = new Audio(url)
      audioRef.current = audio

      if (!audioCtxRef.current) {
        audioCtxRef.current = new AudioContext()
      }
      const audioCtx = audioCtxRef.current
      if (audioCtx.state === 'suspended') await audioCtx.resume()

      const source = audioCtx.createMediaElementSource(audio)
      const analyser = audioCtx.createAnalyser()
      analyser.fftSize = 256
      analyser.smoothingTimeConstant = 0.7
      source.connect(analyser)
      analyser.connect(audioCtx.destination)

      const data = new Uint8Array(analyser.frequencyBinCount)

      const tick = (): void => {
        analyser.getByteFrequencyData(data)
        const avg = data.reduce((sum, v) => sum + v, 0) / data.length
        setLevel(avg / 255)
        rafRef.current = requestAnimationFrame(tick)
      }

      await new Promise<void>((resolve, reject) => {
        audio.onplay = () => {
          setIsSpeaking(true)
          tick()
        }
        audio.onended = () => {
          cleanupPlayback()
          resolve()
        }
        audio.onerror = () => {
          cleanupPlayback()
          reject(new Error('JARVIS: audio playback failed'))
        }
        audio.play().catch(reject)
      })
    },
    [muted, cleanupPlayback]
  )

  return { isSpeaking, level, speak, stop }
}
