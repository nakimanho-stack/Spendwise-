export type EngineState = 'idle' | 'listening' | 'thinking' | 'speaking' | 'error'

export interface ChatEntry {
  id: string
  role: 'user' | 'assistant'
  content: string
  timestamp: number
}
