import { contextBridge, ipcRenderer } from 'electron'

export interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

export interface ConfigStatus {
  hasAnthropicKey: boolean
  hasElevenLabsKey: boolean
}

const jarvisApi = {
  /** Send the full conversation so far to Claude and get JARVIS's reply text back. */
  chat: (history: ChatMessage[]): Promise<string> => ipcRenderer.invoke('claude:chat', history),

  /** Ask ElevenLabs to synthesize speech for the given text. Resolves to raw MP3 bytes. */
  speak: (text: string): Promise<number[]> => ipcRenderer.invoke('tts:speak', text),

  /** Check whether the required API keys were found in .env. */
  configStatus: (): Promise<ConfigStatus> => ipcRenderer.invoke('config:status')
}

contextBridge.exposeInMainWorld('jarvis', jarvisApi)

export type JarvisApi = typeof jarvisApi
