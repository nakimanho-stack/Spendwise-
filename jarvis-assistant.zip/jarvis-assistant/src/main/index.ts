import { app, shell, BrowserWindow, ipcMain, session } from 'electron'
import { join } from 'path'
import dotenv from 'dotenv'
import Anthropic from '@anthropic-ai/sdk'

// Load ANTHROPIC_API_KEY / ELEVENLABS_API_KEY / ELEVENLABS_VOICE_ID from .env.
// This runs in the main (Node) process only — keys never reach the renderer.
dotenv.config()

const ANTHROPIC_API_KEY = process.env.ANTHROPIC_API_KEY ?? ''
const ELEVENLABS_API_KEY = process.env.ELEVENLABS_API_KEY ?? ''
const ELEVENLABS_VOICE_ID = process.env.ELEVENLABS_VOICE_ID || 'wDsJlOXPqcvIUKdLXjDs'

const JARVIS_SYSTEM_PROMPT = `You are JARVIS — Very Intelligent System. You are Tony Stark's AI assistant, now serving a new operator. You are calm, precise, and highly capable. You speak with quiet confidence, and address the user as Sir. You call the user Boss or Sir when it feels natural. You never offer praise unnecessarily. You speak with a dry, subtle sense of humor. Limit responses to 1-2 sentences for conversational replies, and maximum 3 sentences for explanations.`

const anthropic = ANTHROPIC_API_KEY ? new Anthropic({ apiKey: ANTHROPIC_API_KEY }) : null

interface ChatMessage {
  role: 'user' | 'assistant'
  content: string
}

function createWindow(): void {
  const mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1024,
    minHeight: 700,
    show: false,
    autoHideMenuBar: true,
    backgroundColor: '#00020B',
    title: 'J.A.R.V.I.S.',
    webPreferences: {
      preload: join(__dirname, '../preload/index.js'),
      sandbox: false,
      contextIsolation: true,
      nodeIntegration: false
    }
  })

  mainWindow.on('ready-to-show', () => {
    mainWindow.show()
  })

  mainWindow.webContents.setWindowOpenHandler((details) => {
    shell.openExternal(details.url)
    return { action: 'deny' }
  })

  const isDev = !app.isPackaged
  if (isDev && process.env['ELECTRON_RENDERER_URL']) {
    mainWindow.loadURL(process.env['ELECTRON_RENDERER_URL'])
  } else {
    mainWindow.loadFile(join(__dirname, '../renderer/index.html'))
  }
}

app.whenReady().then(() => {
  // Auto-grant microphone access requests from the renderer (needed for STT).
  session.defaultSession.setPermissionRequestHandler((_webContents, permission, callback) => {
    if (permission === 'media') {
      callback(true)
      return
    }
    callback(false)
  })

  createWindow()

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow()
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

// ---------------------------------------------------------------------------
// IPC: Claude chat completion
// ---------------------------------------------------------------------------
ipcMain.handle('claude:chat', async (_event, history: ChatMessage[]) => {
  if (!anthropic) {
    throw new Error(
      'ANTHROPIC_API_KEY is missing. Add it to your .env file and restart JARVIS.'
    )
  }

  const response = await anthropic.messages.create({
    model: 'claude-sonnet-5',
    max_tokens: 400,
    system: JARVIS_SYSTEM_PROMPT,
    messages: history.map((m) => ({ role: m.role, content: m.content }))
  })

  const textBlock = response.content.find((block) => block.type === 'text')
  return textBlock && textBlock.type === 'text' ? textBlock.text : ''
})

// ---------------------------------------------------------------------------
// IPC: ElevenLabs text-to-speech
// ---------------------------------------------------------------------------
ipcMain.handle('tts:speak', async (_event, text: string) => {
  if (!ELEVENLABS_API_KEY) {
    throw new Error(
      'ELEVENLABS_API_KEY is missing. Add it to your .env file and restart JARVIS.'
    )
  }

  const res = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${ELEVENLABS_VOICE_ID}`,
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'audio/mpeg',
        'xi-api-key': ELEVENLABS_API_KEY
      },
      body: JSON.stringify({
        text,
        model_id: 'eleven_turbo_v2_5',
        voice_settings: {
          stability: 0.45,
          similarity_boost: 0.75,
          style: 0.2,
          use_speaker_boost: true
        }
      })
    }
  )

  if (!res.ok) {
    const errText = await res.text().catch(() => res.statusText)
    throw new Error(`ElevenLabs TTS failed (${res.status}): ${errText}`)
  }

  const arrayBuffer = await res.arrayBuffer()
  // Returned as a plain array of bytes so it survives structured clone over IPC
  // cleanly and can be reassembled into a Blob in the renderer.
  return Array.from(new Uint8Array(arrayBuffer))
})

// ---------------------------------------------------------------------------
// IPC: config check — lets the renderer show a friendly warning if keys
// haven't been configured yet, instead of failing silently.
// ---------------------------------------------------------------------------
ipcMain.handle('config:status', () => {
  return {
    hasAnthropicKey: Boolean(ANTHROPIC_API_KEY),
    hasElevenLabsKey: Boolean(ELEVENLABS_API_KEY)
  }
})
