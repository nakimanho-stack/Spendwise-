# J.A.R.V.I.S.

A Stark-Industries-styled desktop AI assistant. Electron + React + TypeScript + Tailwind CSS, voice-driven by Claude (conversation) and ElevenLabs (speech).

## Stack

- **Electron** (main process) — window, mic permission, and holds your API keys
- **electron-vite** — bundles main / preload / renderer with hot reload
- **React 18 + TypeScript** — UI
- **Tailwind CSS** — dark HUD theme (`#00020B` background, `#00E1FE` cyan accents)
- **Claude API** (`@anthropic-ai/sdk`) — conversation
- **ElevenLabs API** — text-to-speech
- **Web Speech API** (built into Chromium/Electron) — speech-to-text, no extra key needed

## 1. Install

```bash
npm install
```

## 2. Configure your keys

```bash
cp .env.example .env
```

Edit `.env`:

```
ANTHROPIC_API_KEY=sk-ant-...
ELEVENLABS_API_KEY=...
ELEVENLABS_VOICE_ID=wDsJlOXPqcvIUKdLXjDs
```

`.env` is only ever read by the **main** process (`src/main/index.ts`). Your keys are never bundled into the renderer/browser bundle — the UI talks to Claude and ElevenLabs through IPC (`window.jarvis.chat`, `window.jarvis.speak`), not by calling the APIs directly.

## 3. Run

```bash
npm start
```

This launches `electron-vite dev`, which starts the renderer dev server and boots the Electron window pointed at it, with hot reload for the UI.

On first launch, grant the app microphone access when your OS prompts you (Electron auto-approves the in-app permission request; the OS-level mic permission prompt still applies on macOS/Windows).

## How it works

1. Tap the large mic button in the control bar. The browser's built-in `SpeechRecognition` starts listening and automatically detects when you stop talking (no push-to-talk needed).
2. Your final transcript is sent to Claude via IPC, with the JARVIS system prompt (calm, precise, addresses you as "Sir"/"Boss", 1–3 sentence replies).
3. Claude's reply is sent to ElevenLabs for TTS; the resulting audio plays back in the renderer, and the central hexagon/ring visualizer pulses in sync with the audio amplitude.
4. The speaker icon in the control bar mutes JARVIS's voice output (text replies still appear in the transcript log).

## Build a distributable

```bash
npm run build:win    # or build:mac / build:linux
```

Output lands in `release/`.

## Notes

- Speech recognition in Chromium routes audio through Google's speech service, so it needs an internet connection — same as Chrome's dictation feature.
- If either API key is missing, the HUD shows a yellow warning banner instead of failing silently.
- Model used for conversation: `claude-sonnet-5`. Swap the `model` field in `src/main/index.ts` if you'd like a different one.
