/** @type {import('tailwindcss').Config} */
export default {
  content: ['./src/renderer/index.html', './src/renderer/src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        void: '#00020B',
        panel: '#020714',
        cyan: {
          core: '#00E1FE',
          dim: '#0A6E82',
          faint: '#063241'
        }
      },
      fontFamily: {
        display: ['"Orbitron"', '"Rajdhani"', 'sans-serif'],
        mono: ['"Share Tech Mono"', '"Rajdhani"', 'monospace']
      },
      keyframes: {
        'pulse-glow': {
          '0%, 100%': { opacity: '0.55', filter: 'drop-shadow(0 0 6px #00E1FE)' },
          '50%': { opacity: '1', filter: 'drop-shadow(0 0 22px #00E1FE)' }
        },
        'spin-slow': {
          '0%': { transform: 'rotate(0deg)' },
          '100%': { transform: 'rotate(360deg)' }
        },
        'spin-reverse-slow': {
          '0%': { transform: 'rotate(360deg)' },
          '100%': { transform: 'rotate(0deg)' }
        },
        scanline: {
          '0%': { transform: 'translateY(-100%)' },
          '100%': { transform: 'translateY(100%)' }
        },
        flicker: {
          '0%, 100%': { opacity: '1' },
          '92%': { opacity: '1' },
          '93%': { opacity: '0.6' },
          '94%': { opacity: '1' }
        }
      },
      animation: {
        'pulse-glow': 'pulse-glow 2.4s ease-in-out infinite',
        'spin-slow': 'spin-slow 18s linear infinite',
        'spin-reverse-slow': 'spin-reverse-slow 24s linear infinite',
        scanline: 'scanline 6s linear infinite',
        flicker: 'flicker 6s ease-in-out infinite'
      }
    }
  },
  plugins: []
}
